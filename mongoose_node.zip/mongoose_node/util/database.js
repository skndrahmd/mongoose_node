const mongoose = require("mongoose");

// Connection URL
const MONGODB_URI = "mongodb://localhost:27017/";

// Connect to MongoDB
mongoose
  .connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to MongoDB");
    // Additional initialization code here
  })
  .catch((err) => {
    console.error("Error connecting to MongoDB:", err);
  });

// Get the MongoDB connection object
const db = mongoose.connection;

// Handle MongoDB connection errors
db.on("error", (err) => {
  console.error("MongoDB connection error:", err);
});

// Handle MongoDB disconnection
db.on("disconnected", () => {
  console.log("Disconnected from MongoDB");
});

// Handle MongoDB reconnection
db.on("reconnected", () => {
  console.log("Reconnected to MongoDB");
});

// Export the MongoDB connection object for use in other parts of your application
module.exports = db;
