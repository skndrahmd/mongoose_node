const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const connectToDb = require("./util/database");
const productRoutes = require("./routes/productRoutes");

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());

connectToDb;

app.use("/", productRoutes);

app.listen(3002, (req, res, next) => {
  console.log("Listening at port 3002...");
});
