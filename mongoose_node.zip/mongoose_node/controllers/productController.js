const Product = require("../models/productModel")


exports.getAllProducts = async (req, res, next) => {
    await Product.find({})
      .then((products) => {
        console.log(products);
        res.status(201).json(products);
      })
      .catch((err) => console.log(err));
  }

exports.getProduct = async (req, res, next) => {
    const id = req.params.id;
    try {
      await Product.findById(id)
        .then((product) => {
          console.log(product);
          res.status(201).json(product);
        })
        .catch((err) => console.log(err));
    } catch (e) {
      console.log(e);
    }
  }

exports.addProduct = async (req, res, next) => {
    try {
      const { name, description, price, category } = req.body;
      await Product.create({
        name,
        description,
        price,
        category,
      })
        .then((newProduct) => {
          console.log(newProduct);
          res.status(201).json(newProduct);
        })
        .catch((e) => console.log(e));
    } catch (e) {
      console.log(e);
    }
  }


exports.updateProduct = async (req, res, next) => {
    const id = req.params.id;
    const { name, description, price, category } = req.body;
  
    try {
      const updatedProduct = await Product.findByIdAndUpdate(
        id,
        { name, description, price, category },
        { new: true }
      );
  
      if (!updatedProduct) {
        return res.status(404).json({ error: "Product not found" });
      }
  
      res.status(200).json(updatedProduct);
    } catch (err) {
      console.error("Error updating product:", err);
      res.status(500).json({ error: "Internal Server Error" });
    }
  }

exports.deleteProduct = async (req, res, next) => {
    const id = req.params.id;
    try {
      await Product.findByIdAndDelete(id)
        .then((deletedProduct) => {
          res.status(201).json(deletedProduct);
          console.log("Product was successfully deleted!");
        })
        .catch((e) => console.log(e));
    } catch (e) {
      console.log(e);
    }
  }
